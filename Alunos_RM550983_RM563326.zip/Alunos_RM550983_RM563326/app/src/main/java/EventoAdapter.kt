
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import br.com.ogustavoress.alunos_rm550983_rm563326.R

class EventoAdapter(
    private val listaEventos: MutableList<EventoExtremo>,
    private val onExcluirClick: (Int) -> Unit
) :RecyclerView.Adapter<EventoAdapter.EventoViewHolder>() {

    class EventoViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        val textLocal: TextView = itemView.findViewById(R.id.textLocal)
        val textTipo: TextView = itemView.findViewById(R.id.textTipo)
        val textImpacto: TextView = itemView.findViewById(R.id.textImpacto)
        val textData: TextView = itemView.findViewById(R.id.textData)
        val textAfetados: TextView = itemView.findViewById(R.id.textAfetados)
        val btnExcluir: Button = itemView.findViewById(R.id.btnExcluir)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_evento_extremo, parent, false)
        return EventoViewHolder(view)
    }

    override fun onBindViewHolder(holder: EventoViewHolder, position: Int) {
        val evento = listaEventos[position]

        holder.textLocal.text = "Local: ${evento.local}"
        holder.textTipo.text = "️Tipo: ${evento.tipo}"
        holder.textImpacto.text = "Impacto: ${evento.impacto}"
        holder.textData.text = "Data: ${evento.data}"
        holder.textAfetados.text = "Afetados: ${evento.afetados}"

        holder.btnExcluir.setOnClickListener {
            onExcluirClick(position)
        }
    }

    override fun getItemCount(): Int = listaEventos.size

}