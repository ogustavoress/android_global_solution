package br.com.ogustavoress.alunos_rm550983_rm563326

import EventoAdapter
import EventoExtremo
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: EventoAdapter
    private val listaEventos = mutableListOf<EventoExtremo>()
    private var listaFiltrada = mutableListOf<EventoExtremo>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputLocal = findViewById<EditText>(R.id.inputLocal)
        val inputTipo = findViewById<EditText>(R.id.inputTipo)
        val inputImpacto = findViewById<EditText>(R.id.inputImpacto)
        val inputData = findViewById<EditText>(R.id.inputData)
        val inputAfetados = findViewById<EditText>(R.id.inputAfetados)
        val btnIncluir = findViewById<Button>(R.id.btnIncluir)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewEventos)
        val spinnerFiltro = findViewById<Spinner>(R.id.spinnerFiltro)
        val btnIdentificacao = findViewById<Button>(R.id.btnIdentificacao)

        val adapterSpinner = ArrayAdapter.createFromResource(
            this,
            R.array.tipos_evento,
            android.R.layout.simple_spinner_item
        )
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerFiltro.adapter = adapterSpinner

        recyclerView.layoutManager = LinearLayoutManager(this)
        filtrarLista("Todos")  // Inicializa mostrando todos

        btnIncluir.setOnClickListener {
            val local = inputLocal.text.toString()
            val tipo = inputTipo.text.toString()
            val impacto = inputImpacto.text.toString()
            val data = inputData.text.toString()
            val afetados = inputAfetados.text.toString().toIntOrNull() ?: -1

            if (local.isBlank() || tipo.isBlank() || impacto.isBlank() || data.isBlank()) {
                Toast.makeText(this, "Preencha todos os campos.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (afetados <= 0) {
                Toast.makeText(this, "Número de afetados deve ser maior que zero.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val novoEvento = EventoExtremo(local, tipo, impacto, data, afetados)
            listaEventos.add(novoEvento)

            val tipoSelecionado = spinnerFiltro.selectedItem.toString()
            filtrarLista(tipoSelecionado)

            inputLocal.text.clear()
            inputTipo.text.clear()
            inputImpacto.text.clear()
            inputData.text.clear()
            inputAfetados.text.clear()
        }

        spinnerFiltro.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val tipoSelecionado = parent.getItemAtPosition(position).toString()
                filtrarLista(tipoSelecionado)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                filtrarLista("Todos")
            }
        }

        btnIdentificacao.setOnClickListener {
            val intent = Intent(this, IdentificacaoActivity::class.java)
            startActivity(intent)
        }
    }

    private fun filtrarLista(tipo: String) {
        listaFiltrada = if (tipo == "Todos") {
            listaEventos.toMutableList()
        } else {
            listaEventos.filter { it.tipo.equals(tipo, ignoreCase = true) }.toMutableList()
        }

        adapter = EventoAdapter(listaFiltrada) { posicao ->
            val itemOriginal = listaFiltrada[posicao]
            val indexOriginal = listaEventos.indexOf(itemOriginal)
            listaEventos.removeAt(indexOriginal)
            filtrarLista(tipo)
        }

        findViewById<RecyclerView>(R.id.recyclerViewEventos).adapter = adapter
    }
}
