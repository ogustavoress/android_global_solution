data class EventoExtremo (
    val local: String,
    val tipo: String,
    val impacto: String,
    val data: String,
    val afetados: Int
)