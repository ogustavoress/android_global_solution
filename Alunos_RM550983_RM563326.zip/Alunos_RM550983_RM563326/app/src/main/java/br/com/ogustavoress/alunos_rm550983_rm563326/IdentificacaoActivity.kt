package br.com.ogustavoress.alunos_rm550983_rm563326

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class IdentificacaoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_identificacao)
    }
}
